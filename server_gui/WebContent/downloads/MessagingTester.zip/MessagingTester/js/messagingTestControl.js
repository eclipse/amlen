/*
 * Copyright (c) 2012-2021 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 * 
 * SPDX-License-Identifier: EPL-2.0
 */
//
// requires messagingTest.js
//

MessagingTestControl = (function (global) {
	
	var controller;
	var display;

	$(document).ready(function() {
		// do any needed setup here
		controller = new MessagingTest.Controller();
		controller.init();
		controller.start();
		display = new MessagingTest.Display(controller);
		display.setBuffers("canvas", "canvas2");
		display.init();
		display.draw();
		initClients();
	});

	function controlChecked(self) {
		var type = self.getAttribute("data-type");
		var client = self.getAttribute("data-client");
		var topic = self.getAttribute("data-topic");
		if (self.checked) {
			if (type == "pub") {
				controller.addPub(client, topic);
			}
			if (type == "sub") {
				controller.addSub(client, topic);
			}
		} else {
			if (type == "pub") {
				controller.removePub(client, topic);
			}
			if (type == "sub") {
				controller.removeSub(client, topic);
			}
		}
	}

	function clearChecks(num) {
		document.getElementById("sub_A_client"+num).checked = false;
		document.getElementById("sub_B_client"+num).checked = false;
		document.getElementById("sub_C_client"+num).checked = false;
		document.getElementById("pub_A_client"+num).checked = false;
		document.getElementById("pub_B_client"+num).checked = false;
		document.getElementById("pub_C_client"+num).checked = false;
	}

	function randomString(length) {
		var source = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		var str = "";
		for (var i = 0; i < length; i++) {
			str += source[Math.floor(Math.random() * source.length)];
		}
		return str;
	}

	function generateSessionId() {
		controller.setSessionId(randomString(5));
		console.log("generated new session id: " + controller.sessionId);
	}

	var testConnection = null;

	function initClients() {
		var html = "";
		var slideTime = 800;

		controller.server.setImage("css/images/messagesight.png");
		controller.server.pos = { x: 400, y: 80 };

		controller.addClient("Web Client 1", "WebClient1", { x: 100, y: 35 }, function() {
			$("#client1").slideDown(slideTime);
			$("#client1_button").hide();
			clearChecks(1);
		}, function() {
			$("#client1").slideUp(slideTime);
			$("#client1_button").show();
		});
		controller.addClient("Web Client 2", "WebClient2", { x: 90, y: 190 }, function() {
			$("#client2").slideDown(slideTime);
			$("#client2_button").hide();
			clearChecks(2);
		}, function() {
			$("#client2").slideUp(slideTime);
			$("#client2_button").show();
		});
		controller.addClient("Web Client 3", "WebClient3", { x: 100, y: 335 }, function() {
			$("#client3").slideDown(slideTime);
			$("#client3_button").hide();
			clearChecks(3);
		}, function() {
			$("#client3").slideUp(slideTime);
			$("#client3_button").show();
		});
		controller.addClient("Web Client 4", "WebClient4", { x: 420, y: 305 }, function() {
			$("#client4").slideDown(slideTime);
			$("#client4_button").hide();
			clearChecks(4);
		}, function() {
			$("#client4").slideUp(slideTime);
			$("#client4_button").show();
		});
		controller.addClient("Web Client 5", "WebClient5", { x: 500, y: 285 }, function() {
			$("#client5").slideDown(slideTime);
			$("#client5_button").hide();
			clearChecks(5);
		}, function() {
			$("#client5").slideUp(slideTime);
			$("#client5_button").show();
		});
		controller.getClientByName("Web Client 1").setImage("css/images/webclient.png");
		controller.getClientByName("Web Client 2").setImage("css/images/webclient.png");
		controller.getClientByName("Web Client 3").setImage("css/images/webclient.png");
		controller.getClientByName("Web Client 4").setImage("css/images/webclient.png");
		controller.getClientByName("Web Client 5").setImage("css/images/webclient.png");

		controller.getClientByName("Web Client 1").setPaths({
			connectionPath: { start: { x: 130, y: 40 }, end: { x: 300, y: 55 } }
		});
		controller.getClientByName("Web Client 2").setPaths({
			connectionPath: { start: { x: 115, y: 175 }, end: { x: 300, y: 113 } }
		});
		controller.getClientByName("Web Client 3").setPaths({
			connectionPath: { start: { x: 130, y: 310 }, end: { x: 340, y: 125 } }
		});
		controller.getClientByName("Web Client 4").setPaths({
			connectionPath: { start: { x: 415, y: 250 }, end: { x: 405, y: 125 } }
		});
		controller.getClientByName("Web Client 5").setPaths({
			connectionPath: { start: { x: 480, y: 240 }, end: { x: 445, y: 122 } }
		});

		// build HTML controls
		for (var i in controller.clients) {
			var clientName = "client"+(Math.round(i) + 1);
			var displayName = controller.clients[i].name;
			html += "<div class='clientControl' id='"+clientName+"_controls'>";
			html += "<center><p><b>"+displayName+"</b></p>";
			html += "<input class='connectButton' type='button' id='"+clientName+"_button' value='Connect' onclick='MessagingTestControl.connectClient(\""+displayName+"\");' disabled /></center>";
			html += "<div class='controls' id='"+clientName+"' style='display: none'>";
			html += "<table>";
			html += "<tr><td>Pub</td><td></td><td>Sub</td></tr>";
			for (var j in MessagingTest.Topics) {
				var topicName = MessagingTest.Topics[j].name;
				html += "<tr>";
				html += "<td><input id='pub_"+topicName+"_"+clientName+"' data-type='pub' data-topic='"+topicName+"' data-client='"+displayName+"' onclick='MessagingTestControl.controlChecked(this)' type='checkbox' /></td>";
				html += "<td><span class='topic"+topicName+"'>Topic "+topicName+"</span></td>";
				html += "<td><input id='sub_"+topicName+"_"+clientName+"' data-type='sub' data-topic='"+topicName+"' data-client='"+displayName+"' onclick='MessagingTestControl.controlChecked(this)' type='checkbox' /></td>";
				html += "</tr>";
			}
			html += "</table>";
			html += "</div>";
			html += "<span id='"+clientName+"_stats'></span>";
			html += "</div>";
		}
		document.getElementById("controls").innerHTML = html;

		updateStats(0, 0);
	}

	function connectClient(name) {
		controller.connectClient(name);
	}

	function establishConnection() {
		hideMessage();
		generateSessionId();
		messageSightServer = document.getElementById("ipField").value;
		messageSightPort = parseFloat(document.getElementById("portField").value);
		document.getElementById("serverStatus").innerHTML = "<b>Attempting connection...</b><br>" + messageSightServer + ":" + messageSightPort;
		var test = new Messaging.Client(messageSightServer, messageSightPort, "MessagingTest_" + controller.sessionId);

		var opts = {
			timeout: 5,
			keepAliveInterval: 7200,
			cleanSession: true,
			useSSL: false
		};

		test.onMessageArrived = function(message) {
			var topic = message.destinationName;
			var payload = message.payloadString;
		}

		opts.onSuccess = function() { 
			document.getElementById("serverStatus").innerHTML = "<b>Connected to server!</b><br>" + messageSightServer + ":" + messageSightPort;
			controller.getClientByName("Web Client 1").connectMQTT(messageSightServer, messageSightPort);
			controller.getClientByName("Web Client 2").connectMQTT(messageSightServer, messageSightPort);
			controller.getClientByName("Web Client 3").connectMQTT(messageSightServer, messageSightPort);
			controller.getClientByName("Web Client 4").connectMQTT(messageSightServer, messageSightPort);
			controller.getClientByName("Web Client 5").connectMQTT(messageSightServer, messageSightPort);
			document.getElementById("client1_button").disabled = false;
			document.getElementById("client2_button").disabled = false;
			document.getElementById("client3_button").disabled = false;
			document.getElementById("client4_button").disabled = false;
			document.getElementById("client5_button").disabled = false;
			document.getElementById("globalConnect_button").disabled = true;
			document.getElementById("ipField").disabled = true;
			document.getElementById("portField").disabled = true;
			document.getElementById("sessionId").innerHTML = "Browser ID: <b>"+controller.sessionId+"</b>";
			hideMessage();
		}
		opts.onFailure = function() { 
			document.getElementById("serverStatus").innerHTML = "<b>Failed to connect!</b><br>" + messageSightServer + ":" + messageSightPort;
		}
		test.onConnectionLost = function(self, reason) {
			document.getElementById("serverStatus").innerHTML = "<b>Failed to connect!</b><br>" + messageSightServer + ":" + messageSightPort;
			document.getElementById("sessionId").innerHTML = "&nbsp;";

			document.getElementById("client1_button").disabled = true;
			document.getElementById("client2_button").disabled = true;
			document.getElementById("client3_button").disabled = true;
			document.getElementById("client4_button").disabled = true;
			document.getElementById("client5_button").disabled = true;
			document.getElementById("globalConnect_button").disabled = false;
			document.getElementById("ipField").disabled = false;
			document.getElementById("portField").disabled = false;
			for (var i in controller.clients) {
				try {
					controller.clients[i].close();
				} catch (e) { }
			}
		}

		try {
			test.connect(opts);
		} catch (e) { 
			document.getElementById("serverStatus").innerHTML = "<b>Connection error!</b><br>" + messageSightServer + ":" + messageSightPort;
		};
		test.receivedHeartbeat = true;

		testConnection = test;
	}

	function updateStats(lastSum, count) {
		var sum = 0;
		for (var i in controller.clients) {
			var clientName = "client"+(Math.round(i) + 1);
			if (controller.clients[i].connected) {
				sum += controller.clients[i].recvMsgCount + controller.clients[i].sendMsgCount;
			}
		}

		if (count % 10 == 0) {
			document.getElementById("serverThroughput").innerHTML = "Throughput: <b><span id='serverThroughput_val'>" + (sum - lastSum) + "</span></b> msgs/sec";
			setTimeout(function() { updateStats(sum, count+1); }, 100);
		} else {
			setTimeout(function() { updateStats(lastSum, count+1); }, 100);
		}
	}

	function setMessage(text) {
		$("#messageArea")[0].innerHTML = text;
		$("#messageArea").slideDown(1000);
	}
	function hideMessage() {
		$("#messageArea").slideUp(1000);
	}

	function getUrlVars() {
		var vars = {};
		var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
			vars[key] = value;
		});
		return vars;
	}

	$(document).ready(function() {
		if(!window.WebSocket) {
			alert("This browser does not support HTML5 Web Sockets.  Please switch to an updated browser.");
		}
	});


	var messageSightServer = getUrlVars()["ip"];
	if (messageSightServer == undefined || messageSightServer == "") {
		messageSightServer = document.location.hostname;
	}
	if (messageSightServer.match(/[A-Fa-f]/) || messageSightServer.match(/[:]/)) {
		messageSightServer = "[" + messageSightServer + "]";
	}
	console.log("messageSightServer = |" + messageSightServer + "|");
	var messageSightPort = getUrlVars()["port"];

	// Module contents. ("public")
	return {
		establishConnection: establishConnection,
		connectClient: connectClient,
		controlChecked: controlChecked,
	};
})(window);
