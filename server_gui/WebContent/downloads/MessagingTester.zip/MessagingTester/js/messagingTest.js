/*
 * Copyright (c) 2012-2021 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 * 
 * SPDX-License-Identifier: EPL-2.0
 */

//
// requires mqttws31.js
//

MessagingTest = (function (global) {

	function publish(client, topic, message, isBinary) {
		var msgObj = null;
		if (isBinary) {
			var hex = message;        
			var buffer = new ArrayBuffer((hex.length)/2);
			var byteStream = new Uint8Array(buffer); 
			var i = 0;
			while (hex.length >= 2) { 
				var x = parseInt(hex.substring(0, 2), 16);
				hex = hex.substring(2, hex.length);
				byteStream[i++] = x;
			}
			msgObj = new Messaging.Message(buffer);
		} else {
			msgObj = new Messaging.Message(message);
		}
		msgObj.destinationName = topic;
		msgObj.qos = 0; 
		client.send(msgObj);
	}

	var scope = function (f, scope) {
		return function () {
			return f.apply(scope, arguments);
		};
	};

	var buffers = Array();  // holds two canvas objects for double buffering
	var bufferIndex = 0;
	var flipBuffers = function() {
		buffers[1 - bufferIndex][0].style.visibility = 'hidden';
		buffers[bufferIndex][0].style.visibility = 'visible';
		bufferIndex = 1 - bufferIndex;
	}
	var getCanvas = function() {
		return buffers[bufferIndex];
	}

	var Globals = {
		FRAMES_PER_MESSAGE: 80,
		FRAMES_PER_SECOND: 40,
		MESSAGES_PER_SECOND_TOPIC: 5,
		MAX_PENDING: 3
	}

	var MessageType = {
		PUB : {value: 0},
		SUB : {value: 1}
	}

	var Topics = {
		A : {
			name: "A",
			color: "#815454"
		},
		B : {
			name: "B",
			color: "#497c91"
		},
		C : {
			name: "C",
			color: "#768b4e"
		}
	}

	// * Message ************************************************************************
	//
	//   Represents a "message" in the demo, in flight.
	//
	function Message() {
		this.topic = null;
		this.client = null;
		this.type = null;
		this.path = {
			start: {
				x: null,
				y: null
			},
			end: {
				x: null,
				y: null
			}
		};
		this.pos = {
			x: null,
			y: null
		};
		this.delta = {
			x: null,
			y: null
		};
	}

	Message.prototype.draw = function() {
		var context = getCanvas()[0].getContext('2d');
		var radius = 8;
		context.save();
		context.beginPath();
		context.rect(this.pos.x - (radius/2), this.pos.y - (radius/2), radius, radius);
		context.fillStyle = this.topic.color;
		context.fill();
		context.lineWidth = 2;
		context.strokeStyle = "#000";
		context.globalAlpha = this._getOpacity();
		context.stroke();
		context.restore();
	}
		
	Message.prototype.update = function() {
		var curDelta = this._getDelta();
		this.pos.x += curDelta.x;
		this.pos.y += curDelta.y;
		if ((Math.round(this.pos.x) > Math.round(this.path.end.x) && this.delta.x > 0) ||
			(Math.round(this.pos.x) < Math.round(this.path.end.x) && this.delta.x < 0)) {
			this.isDone();
		}
	}

	Message.prototype._getDelta = function() {
		var perc = this._getPerc();
		if (perc > 0.5) {
			perc = 1 - perc;
		}
		var scale = 1.0 + (2 * perc);
		var retDelta = {
			x: this.delta.x * scale,
			y: this.delta.y * scale
		};
		return retDelta;
	}

	Message.prototype._getOpacity = function() {
		var perc = this._getPerc();
		var opacity = Math.abs(0.5 - perc) * 2;
		opacity = Math.pow(opacity, 4);
		opacity = 1 - opacity;
		if (opacity < 0) { 
			opacity = 0;
		} else if (opacity > 1) {
			opacity = 1;
		}
		return opacity;
	}

	Message.prototype._getPerc = function() {
		return Math.abs(this.path.start.x - this.pos.x) / Math.abs(this.path.end.x - this.path.start.x);
	}





	// * Client ************************************************************************ 
	//
	//   Represents a "web client" in the demo.  Handles both actual message publication and "visual" publication.
	//
	function Client(controller) {
		this.image = null;
		this.controller = controller;
		this.mqttclient = null;
		this.pendingPubMessages = null;
		this.pubMessages = null;
		this.subMessages = null;
		this.connected = false;
		this.connectCallback = null;
		this.errorCallback = null;
		this.name = null;
		this.sendMsgCount = null;
		this.recvMsgCount = null;
		this.pos = { x: null, y: null };
		this.size = { w: null, h: null };

		this.connectionPath = {
			start: { x: null, y: null },
			end: { x: null, y: null },
			perc: 0
		}
		this.pubMessagePath = {
			start: { x: null, y: null },
			end: { x: null, y: null }
		}
		this.subMessagePath = {
			start: { x: null, y: null },
			end: { x: null, y: null }
		}

		this.pubTopics = null;
		this.subTopics = null;
	}

	Client.prototype.init = function(name, shortname, pos, callback, errback) {
		this.connectCallback = callback;
		this.errorCallback = errback;
		
		this.pendingPubMessages = Array();
		this.subMessages = Array();
		this.pubMessages = Array();
		this.pubTopics = Array();
		this.subTopics = Array();

		this.name = name;
		this.shortname = shortname;
		this.pos = pos;
		this.size = { w: 80, h: 60 };
		this.sendMsgCount = 0;
		this.recvMsgCount = 0;

		this.setPaths();
	}

	Client.prototype.connectMQTT = function(server, port) {
		if (server == null) {
			server = document.location.hostname;
		}
		if (port == null) {
			port = "16102";
		}
		this.mqttclient = new Messaging.Client(server, parseFloat(port), this.shortname + "_" + this.controller.sessionId);
		this.connectOpts = {
			timeout: 5,
			keepAliveInterval: 7200,
			cleanSession: true,
			useSSL: false
		};
		var self = this;
		this.connectOpts.onSuccess = function() { 
			self.connect();
			if (self.connectCallback != null) {
				self.connectCallback();
			}
		}
		this.connectOpts.onFailure = function() { 
			console.log(self.name + " has an error!"); 
		}
		this.mqttclient.onMessageArrived = function(message) {
			self.receiveMessage(message);
		}
		this.mqttclient.onConnectionLost = function() {
			console.log(self.name + " onconnectionlost()");
			self.close();
		}
	}

	Client.prototype.close = function() {
		this.pubMessages = Array();
		this.pendingPubMessages = Array();
		this.subMessages = Array();
		this.pubTopics = Array();
		this.subTopics = Array();
		console.log(this.name + " lost connection!"); 
		this.connected = false;
		
		if (this.mqttclient && this.mqttclient._connected) {
			this.mqttclient.disconnect();
		}
		this.mqttclient = null;
		if (this.errorCallback) {
			this.errorCallback();
		}

		// start thread to draw connection animation
		var self = this;
		var id = setInterval(function() {
			self.connectionPath.perc -= 2; 
			if (self.connectionPath.perc < 0) { 
				self.connectionPath.perc = 0; 
			} 
		}, 1000.0 / 50);
		setTimeout("clearInterval("+id+");", 1500);
	}

	Client.prototype.setPaths = function(paths) {
		if (paths != null) {
			this.connectionPath.start.x = paths.connectionPath.start.x;
			this.connectionPath.end.x = paths.connectionPath.end.x;
			this.connectionPath.start.y = paths.connectionPath.start.y;
			this.connectionPath.end.y = paths.connectionPath.end.y;

			var slope = (this.connectionPath.end.y - this.connectionPath.start.y) / (this.connectionPath.end.x - this.connectionPath.start.x);
			var perp = -1 / slope;
			var div = Math.sqrt(perp * perp + 1);
			var perpVec = {
				x: 1 / div,
				y: perp / div
			}
			perpVec.x *= 10;
			perpVec.y *= 10;

			this.pubMessagePath.start.x = this.connectionPath.start.x + perpVec.x;
			this.pubMessagePath.end.x = this.connectionPath.end.x + perpVec.x;
			this.pubMessagePath.start.y = this.connectionPath.start.y + perpVec.y;
			this.pubMessagePath.end.y = this.connectionPath.end.y + perpVec.y;

			var slope = (this.connectionPath.start.y - this.connectionPath.end.y) / (this.connectionPath.start.x - this.connectionPath.end.x);
			var perp = -1 / slope;
			var div = Math.sqrt(perp * perp + 1);
			var perpVec = {
				x: 1 / div,
				y: perp / div
			}
			perpVec.x *= 10;
			perpVec.y *= 10;

			this.subMessagePath.start.x = this.connectionPath.end.x - perpVec.x;
			this.subMessagePath.end.x = this.connectionPath.start.x - perpVec.x;
			this.subMessagePath.start.y = this.connectionPath.end.y - perpVec.y;
			this.subMessagePath.end.y = this.connectionPath.start.y - perpVec.y;
		}
	}

	Client.prototype.setImage = function(src) {
		this.image = new Image();
		this.image.src = src;
		this.size.w = this.image.width;
		this.size.h = this.image.height;
	}

	Client.prototype.draw = function() {
		if (this.image != null) {
			var context = getCanvas()[0].getContext('2d');
			context.drawImage(this.image, this.pos.x - (this.image.width / 2), this.pos.y - (this.image.height / 2), 
										  this.image.width, this.image.height);
		}
	}

	Client.prototype.connect = function() {
		this.controller.server.connections[this.name] = this;
		this.connected = true;

		// start thread to add messages from pending queue
		this.addFromPending();

		// start thread to draw connection animation
		var id = setInterval((function(client) {
			return function() {
				client.connectionPath.perc += 2; 
				if (client.connectionPath.perc > 100) { 
					client.connectionPath.perc = 100; 
				} 
			}
		})(this), 1000.0 / 50);
		setTimeout("clearInterval("+id+");", 1500);
	}

	Client.prototype.publishMessage = function(topic) {
		if (this.pendingPubMessages.length < Globals.MAX_PENDING) {
			var message = new Message();
			message.client = this;
			message.type = MessageType.PUB;
			message.topic = topic;

			var randomOffsetX = 0;
			var randomOffsetY = 0;

			message.path.start.x = this.pubMessagePath.start.x + randomOffsetX;
			message.path.start.y = this.pubMessagePath.start.y + randomOffsetY;
			message.path.end.x = this.pubMessagePath.end.x + randomOffsetX;
			message.path.end.y = this.pubMessagePath.end.y + randomOffsetY;
			message.pos.x = message.path.start.x;
			message.pos.y = message.path.start.y;
			message.delta.x = (1.0 / Globals.FRAMES_PER_MESSAGE) * (message.path.end.x - message.path.start.x);
			message.delta.y = (1.0 / Globals.FRAMES_PER_MESSAGE) * (message.path.end.y - message.path.start.y);
			message.isDone = (function(c, m) {
				return function() {
					c.controller.server.receivedPublish(m);
					c.pubMessages.shift();
				}
			})(this, message);
			this.pendingPubMessages.push(message);
			this.sendMsgCount++;
			this.controller.server.recvMsgCount++;
		}
	}

	Client.prototype.receiveMessage = function(message) {
		var subMsg = new Message();
		subMsg.client = this;
		subMsg.type = MessageType.SUB;
		var topicName = message.destinationName.split("/")[1][5];
		subMsg.topic = Topics[topicName];

		var randomOffsetX = Math.round(Math.random() * 4) - 2;
		var randomOffsetY = Math.round(Math.random() * 4) - 2;

		subMsg.path.start.x = this.subMessagePath.start.x + randomOffsetX;
		subMsg.path.start.y = this.subMessagePath.start.y + randomOffsetY;
		subMsg.path.end.x = this.subMessagePath.end.x + randomOffsetX;
		subMsg.path.end.y = this.subMessagePath.end.y + randomOffsetY;
		subMsg.pos.x = subMsg.path.start.x;
		subMsg.pos.y = subMsg.path.start.y;
		subMsg.delta.x = (1.0 / Globals.FRAMES_PER_MESSAGE) * (subMsg.path.end.x - subMsg.path.start.x);
		subMsg.delta.y = (1.0 / Globals.FRAMES_PER_MESSAGE) * (subMsg.path.end.y - subMsg.path.start.y);
		subMsg.isDone = (function(c) {
			return function() {
				c.subMessages.shift();
			}
		})(this);
		this.subMessages.push(subMsg);
		this.recvMsgCount++;
		this.controller.server.sendMsgCount++;
	}

	Client.prototype.drawConnection = function() {
		var path = this.connectionPath;
		var xdiff = (path.end.x - path.start.x) * path.perc / 100.0;
		var ydiff = (path.end.y - path.start.y) * path.perc / 100.0;

		var context = getCanvas()[0].getContext('2d');
		context.save();
		context.strokeStyle = "#bbbbbb";
		context.lineWidth = 2;
		context.beginPath();
		context.moveTo(path.start.x, path.start.y);
		context.lineTo(path.start.x + xdiff, path.start.y + ydiff);
		context.closePath();
		context.stroke();
		context.restore();
	}

	Client.prototype.drawMessages = function() {
		for (var i in this.pubMessages) {
			if (i < 10) {
				this.pubMessages[i].draw();
			}
		}
		for (var i in this.subMessages) {
			if (i < 30) {
				this.subMessages[i].draw();
			}
		}
	}

	Client.prototype.addFromPending = function() {
		// add messages from the pending queue
		if (this.pendingPubMessages.length > 0) {
			var msg = this.pendingPubMessages.shift();
			this.pubMessages.push(msg);
		}
		setTimeout(scope(this.controller.getClientByName(this.name).addFromPending, this), 1000 / Globals.MESSAGES_PER_SECOND_TOPIC);
	}

	Client.prototype.update = function() {
		for (var i in this.pubMessages) {
			this.pubMessages[i].update();
		}
		for (var i in this.subMessages) {
			if (i < 100) {
				this.subMessages[i].update();
			}
		}
	}


	// * Server ********************************************************************************* 
	//
	//   Represents "MessageSight" in the demo.  Invokes draw routines for the connected clients.
	//
	function Server(controller) {
		this.image = null;
		this.controller = controller;
		this.connections = null;
		this.sendMsgCount = null;
		this.recvMsgCount = null;

		this.pos = {
			x: null,
			y: null
		};
		this.size = {
			w: null,
			h: null
		}
	}

	Server.prototype.init = function() {
		this.pos = { x: 400, y: 120 };
		this.size = { w: 90, h: 140 };
		this.connections = {};
		this.sendMsgCount = 0;
		this.recvMsgCount = 0;
	}

	Server.prototype.receivedPublish = function(message) {
		try {
			publish(message.client.mqttclient, "MessagingTest_"+this.controller.sessionId+"/Topic"+message.topic.name, "Message from " + message.client.name);
		} catch (e) { console.error(e); }
	}

	Server.prototype.setImage = function(src) {
		this.image = new Image();
		this.image.src = src;
		this.size.w = this.image.width;
		this.size.h = this.image.height;
	}

	Server.prototype.draw = function() {
		if (this.image != null) {
			var context = getCanvas()[0].getContext('2d');
			context.drawImage(this.image, this.pos.x - (this.image.width / 2), this.pos.y - (this.image.height / 2), 
										  this.image.width, this.image.height);
		}
	}

	Server.prototype.drawConnections = function() {
		for (var clientName in this.connections) {
			var client = this.connections[clientName];
			client.drawConnection();
		}
	}

	Server.prototype.drawMessages = function() {
		for (var clientName in this.connections) {
			var client = this.connections[clientName];
			client.drawMessages();
		}
	}





	// * Controller ****************************************************************************** 
	//
	//   Controlling object.  User actions (subscribe, begin publish) invoke Controller functions.
	//
	function Controller() {
		this.messages = Array();
		this.clients = Array();
		this.sessionId = null;
		this.server = new Server(this);
		this.publishing = true;
	}

	Controller.prototype.init = function() {
		this.server.init(); 
	}

	Controller.prototype.setSessionId = function(sessionId) {
		this.sessionId = sessionId;
	}

	// pos = { x: __, y: __ }
	Controller.prototype.addClient = function(name, shortname, pos, connectCallback, errorCallback) {
		var client = new Client(this);
		client.init(name, shortname, pos, connectCallback, errorCallback);
		this.clients.push(client);
	}

	Controller.prototype.connectClient = function(name) {
		if (!this.getClientByName(name).mqttclient) {
			var client = this.getClientByName(name);
			this.getClientByName(name).init(client.name, client.pos, client.connectCallback, client.errorCallback);	
		}
		this.getClientByName(name).mqttclient.connect(this.getClientByName(name).connectOpts);
	}

	Controller.prototype.start = function() {
		this.startPublish(1000);
	}

	Controller.prototype.addPub = function(clientName, topicName) {
		console.log("addPub(" + clientName + ", " + topicName + ")");
		var client = this.getClientByName(clientName);
		var topic = Topics[topicName];
		for (var i in client.pubTopics) {
			if (client.pubTopics[i].name == topic.name) {
				// already has, don't need to add
				return;
			}
		}
		client.pubTopics.push(topic);
	}

	Controller.prototype.removePub = function(clientName, topicName) {
		console.log("removePub(" + clientName + ", " + topicName + ")");
		var client = this.getClientByName(clientName);
		var topic = Topics[topicName];
		for (var i in client.pubTopics) {
			if (client.pubTopics[i].name == topic.name) {
				client.pubTopics.splice(i, 1);
				return;
			}
		}
		// if we reach here, the pub wasn't found
	}

	Controller.prototype.addSub = function(clientName, topicName) {
		console.log("addSub(" + clientName + ", " + topicName + ")");
		var client = this.getClientByName(clientName);
		var topic = Topics[topicName];
		for (var i in client.subTopics) {
			if (client.subTopics[i].name == topic.name) {
				// already has, don't need to add
				return;
			}
		}
		try {
			client.mqttclient.subscribe("MessagingTest_"+this.sessionId+"/Topic"+topic.name);
			client.subTopics.push(topic);
		} catch (e) { console.error(e); }
	}

	Controller.prototype.removeSub = function(clientName, topicName) {
		console.log("removeSub(" + clientName + ", " + topicName + ")");
		var client = this.getClientByName(clientName);
		var topic = Topics[topicName];
		for (var i in client.subTopics) {
			if (client.subTopics[i].name == topic.name) {
				client.subTopics.splice(i, 1);
			}
		}
		try {
			client.mqttclient.unsubscribe("MessagingTest_"+this.sessionId+"/Topic"+topic.name);
		} catch (e) { console.error(e); }
	}

	Controller.prototype.doPublish = function(millis) {
		for (var i in this.clients) {
			if (this.clients[i].connected && this.clients[i].pubTopics != null) {
				for (var j in this.clients[i].pubTopics) {
					this.clients[i].publishMessage(this.clients[i].pubTopics[j]);
				}
			}
		}
		if (this.publishing) {
			var f = scope(this.doPublish, this);
			setTimeout(function() { f(millis); }, millis);
		}
	}
		
	Controller.prototype.startPublish = function(millis) {
		this.doPublish(millis);
	}

	Controller.prototype.update = function() {
		for (var i in this.clients) {
			if (this.clients[i].connected) {
				this.clients[i].update();
			}
		}
		for (var i in this.messages) {
			this.messages[i].update();
		}
	}

	Controller.prototype.getClientByName = function(name) {
		for (var i in this.clients) {
			if (this.clients[i].name == name) {
				return this.clients[i];
			}
		}
		return null;
	}




	// * Display **********
	//
	//  Manages the canvas. 
	//
	function Display(controller) {
		this.controller = controller;
		this.canvas = null;
		this.canvasHeight = null; 
		this.canvasWidth = null;
	}

	Display.prototype.init = function() {
		this.canvasHeight = getCanvas().attr("height");
		this.canvasWidth = getCanvas().attr("width");
	}
	 
	Display.prototype.drawClients = function() {
		for (var i in this.controller.clients) {
			var client = this.controller.clients[i];
			client.draw();
		}
	}

	Display.prototype.drawServer = function() {
		this.controller.server.draw();
	}

	Display.prototype.drawConnections = function() {
		this.controller.server.drawConnections();
	}

	Display.prototype.drawMessages = function() {
		this.controller.server.drawMessages();
	}

	Display.prototype.draw = function() {
		// clear canvas
		var context = getCanvas()[0].getContext('2d');
		context.save();
		context.beginPath();
		context.rect(0, 0, getCanvas()[0].width, getCanvas()[0].height);
		context.fillStyle = "#fff";
		context.fill();
		context.restore();

		this.drawClients();
		this.drawServer();
		this.drawMessages();
		this.drawConnections();
		flipBuffers();
		this.controller.update();
		setTimeout(scope(this.draw, this), 1000 / Globals.FRAMES_PER_SECOND);
	}
	
	Display.prototype.setBuffers = function(id1, id2) {
		buffers.push($("#"+id1));
		buffers.push($("#"+id2));
	}

	// Module contents. ("public")
	return {
		Controller: Controller,
		Display: Display,
		Topics: Topics
	};
})(window);
