/*
 * Copyright (c) 2012-2021 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 * 
 * SPDX-License-Identifier: EPL-2.0
 */

function wlCommonInit(){
	// Common initialization code goes here
}

function getSecretData(){
	var invocationData = {
			adapter: "DummyAdapter",
			procedure: "getSecretData",
			parameters: []
	};
	
	WL.Client.invokeProcedure(invocationData, {
		onSuccess: getSecretData_Callback,
		onFailure: getSecretData_Callback
	});
}

function getSecretData_Callback(response){
	console.log("ltpaToken in received response: " + response.invocationResult.LtpaToken );
	console.dir(response);
	ltpaToken = response.invocationResult.LtpaToken;
	clientID = response.invocationResult.userId;
	//alert("getSecretData_Callback response :: " + JSON.stringify(response));
	//ltpaToken = response['LtpaToken'];
	console.log("ltpaToken: [" + ltpaToken + "]");
	console.log("clientID:  [" + clientID + "]");
	//alert("ltpaToken: [" + ltpaToken + "]");
	//var wlstr = response['WASLTPARealm'];
	//clientID = wlstr['userId'];
}