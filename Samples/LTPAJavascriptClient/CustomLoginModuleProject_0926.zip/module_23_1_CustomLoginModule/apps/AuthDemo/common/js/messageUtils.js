/*
 * Copyright (c) 2012-2021 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 * 
 * SPDX-License-Identifier: EPL-2.0
 */

var client = null;

function init() {
	console.log("init");
	//setReservedCarMsg("No Message... yet!");
}

var SERVER = "10.10.4.85";
//var SERVER = "192.168.238.183";
var PORT = 16102;

function connect() {
	try {
		//client = new Messaging.Client(SERVER, PORT, "MobileRentalClient" + Math.floor(Math.random() * 100000));
		//client = new Messaging.Client(SERVER, PORT, clientID);
		client = new Messaging.Client(SERVER, PORT, "MobileRentalClient");
	} catch (error) {
		alert("Error:"+error);
	}

	client.onMessageArrived = onMessage;
	client.onConnectionLost = onConnectionLost;

	var connectOptions = new Object();
	connectOptions.timeout = parseInt( '15' );
    connectOptions.cleanSession = true;
    connectOptions.keepAliveInterval = parseInt( '60' );   
    //connectOptions.willMessage = willMessage;  // Default is no willMessage
	
	connectOptions.userName = 'IMA_LTPA_AUTH';
    //connectOptions.userName = 'testuser';
	//connectOptions.password = $("ltpaToken")[0].value;
	//connectOptions.password = $('#ltpaToken').val();
	connectOptions.password = ltpaToken;
    //connectOptions.password = '12345';
	console.debug("connectOptions.password: "+ connectOptions.password);
	connectOptions.cleanSession = true;
	connectOptions.useSSL = true;

	connectOptions.onSuccess = onClientConnectSuccess; 
	connectOptions.onFailure = onClientConnectFailure;

	try {
	    client.connect(connectOptions);
	}catch (error) {
		alert("Error:"+error);
	}
	console.debug("call client.connect");
}

function disconnect() {
	client.disconnect();
}

/*
function getAvailableCars() {
	console.log("getAvailableCars()");
	* request a list*
	var topic = "/USER/" + getUsername() + "/APP/#";
	var message = "action=GetAvailableCars,user=" + getUsername();
	publish(topic, message, false);
	
	
	var topic = "/USER/" + getUsername() + "/APP/#";
	var message = "action=GetAvailableCars,user=" + getUsername();
	publish(topic, message, false);
}
*/

function getAvailableCars() {
	console.log("send a request");
	var topic = "/APP/GetAvailableCars/USER/" + getUsername();
	var message = $('#msgInputField').val();
	publish(topic, message, false);
}

function reserveCar(id) {
	console.log("reserveCar()");
	var topic = "/APP/GetAvailCars/USER/" + getUsername();
	var message = "action=ReserveCar,id=" + id + ",user=" + getUsername();
	publish(topic, message, false);
}

function returnCar(id) {
	console.log("reserveCar()");
	var topic = "/MobileRental/Actions/User/" + getUsername();
	var message = "action=ReturnCar,id=" + id + ",user=" + getUsername();
	publish(topic, message, false);
}

function setReservedCarMsg(html) {
	if ($("#sessionInfo_reservedCarMsg")[0].innerHTML != html) {
		$("#sessionInfo_reservedCarMsg").fadeOut({
			complete: function() {
				$("#sessionInfo_reservedCarMsg")[0].innerHTML = html;
				$("#sessionInfo_reservedCarMsg").fadeIn();
			}
		});
	}
}

function onClientConnectSuccess() {
	console.log("connected!");

	// set up sidebar controls
	$("#sessionInfo_disconnected").fadeOut({
		complete: function() {
			$("#sessionInfo_username")[0].innerHTML = getUsername();
			$("#sessionInfo_connected").fadeIn();
			//$("#action_getAvailableCars")[0].disabled = false;
		}
	});
	
	//getAvailableCars();

	// subscribe to reply topic
	//client.subscribe("/MobileRental/Actions/User/" + getUsername() + "/reply", {
	client.subscribe("/APP/LTPATest/reply", {
		onSuccess: function() { console.log("Get your request!"); }
	});
	//client.subscribe("/MobileRental/Notifications/User", {
	//	onSuccess: function() { console.log("subscribed to notifications!"); }
	//});
	
	getAvailableCars();
}

function getUsername() {
	return clientID;
}

function onClientConnectFailure(invocationContext, code, text) { 
	console.log("failed! code=" + code + " text=" + text);
	console.debug("connection failed");
	alert("connection failed");
	if (isConnect == true) {
		isConnect = false;
	}
	$('#AppBody').show();
	$('#AuthBody').hide();
	$('#MsgBody').hide();
}

function onMessage(message) {
	var topic = message.destinationName;
	var payload = JSON.parse(message.payloadString);
	console.log("got msg:", topic, payload);

	//Actions[payload.action](payload);
}


var Actions = {
	GetAvailableCars: function(msg) {
		console.log("GetAvailableCars Action", msg);
		var html = "<div id='availableCars' style='display: none'>";
		html += "<h2>Available Cars</h2>";
		for (var i in msg.carData) {
			var id = msg.carData[i].id;
			var buttonText = "<button style='margin-left";
			var extra = "btn-success";
			var onclick = "reserveCar(" + id + ")";
			var label = "Reserve";
			if (msg.carData[i].user && msg.carData[i].user == getUsername()) {
				extra = "btn-danger";
				onclick = "returnCar(" + id + ")";
				label = "Return";
				setReservedCarMsg("You are driving <b>Car " + id + "</b>!");
			}
			html += "<p>Car " + id + "<button style='margin-left: 20px;' class='btn btn-small "+extra+"' onclick='"+onclick+"'>"+label+"</button></p>";
		}
		html += "</div>";
		$("#mainContent")[0].innerHTML = html;
		$("#availableCars").fadeIn();
	},
	ReserveCar: function(msg) {
		console.log("ReserveCar Action", msg);
		if (msg.success) {
			setReservedCarMsg("You are driving <b>Car " + msg.id + "</b>!");
		}
	},
	ReturnCar: function(msg) {
		console.log("ReturnCar Action", msg);
		if (msg.success) {
			setReservedCarMsg("No car reserved... yet!");
		}
	},
	NeedUpdate: function(msg) {
		console.log("NeedUpdate Action", msg);
		getAvailableCars();
	},
	unknown: function(msg) {
		console.error("unknown Action", msg);
	}
};

function onConnectionLost() {
	console.log("connection lost!");
	//$("#action_getAvailableCars")[0].disabled = true;
	$("#sessionInfo_connected").fadeOut({
		complete: function() {
			$("#sessionInfo_disconnected").fadeIn();
			$("#mainContent")[0].innerHTML = "";
		}
	});
}

function publish(topic, message, isBinary) {
	var msgObj = null;
	if (isBinary) {
		var hex = message;        
		var buffer = new ArrayBuffer((hex.length)/2);
		var byteStream = new Uint8Array(buffer); 
		var i = 0;
		while (hex.length >= 2) { 
			var x = parseInt(hex.substring(0, 2), 16);
			hex = hex.substring(2, hex.length);
			byteStream[i++] = x;
		}
		msgObj = new Messaging.Message(buffer);
	} else {
		msgObj = new Messaging.Message(message);
	}
	msgObj.destinationName = topic;
	msgObj.qos = 0; 
	client.send(msgObj);
}