/*
 * Copyright (c) 2006-2021 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 * 
 * SPDX-License-Identifier: EPL-2.0
 */

var customAuthenticatorRealmChallengeHandler = WL.Client.createChallengeHandler("WASLTPARealm");

customAuthenticatorRealmChallengeHandler.isCustomResponse = function(response) {
    if (!response || response.responseText === null) {
        return false;
    }
    var indicatorIdx = response.responseText.search('j_security_check');
    
    if (indicatorIdx >= 0){
		return true;
	}  
	return false;
};

customAuthenticatorRealmChallengeHandler.handleChallenge = function(response) {
	$('#AppBody').hide();
	$('#AuthBody').show();
	$('#passwordInputField').val('');
};

customAuthenticatorRealmChallengeHandler.submitLoginFormCallback = function(response) {
    var isLoginFormResponse = customAuthenticatorRealmChallengeHandler.isCustomResponse(response);
    if (isLoginFormResponse){
    	customAuthenticatorRealmChallengeHandler.handleChallenge(response);
    } else {
    	$('#MsgBody').show();
		$('#AppBody').hide();
		$('#AuthBody').hide();
		customAuthenticatorRealmChallengeHandler.submitSuccess();
    }
};

$('#loginButton').bind('click', function () {
    var reqURL = '/j_security_check';
    var options = {};
    options.parameters = {
        j_username : $('#usernameInputField').val(),
        j_password : $('#passwordInputField').val()
    };
    options.headers = {};
    customAuthenticatorRealmChallengeHandler.submitLoginForm(reqURL, options, customAuthenticatorRealmChallengeHandler.submitLoginFormCallback);
});

$('#cancelButton').bind('click', function () {
	customAuthenticatorRealmChallengeHandler.submitFailure();
	$('#AppBody').show();
	$('#AuthBody').hide();
	$('#MsgBody').hide();
});

var isConnect = false;
$('#sendMsgButton').bind('click', function () {
	init();
	if (isConnect == false) {
	    connect();
	    isConnect = true;
    }
    getAvailableCars();
});

$('#exitButton').bind('click', function () {
	disconnect();
	if (isConnect == true) {
		isConnect = false;
	}
	$('#AppBody').show();
	$('#AuthBody').hide();
	$('#MsgBody').hide();
});
