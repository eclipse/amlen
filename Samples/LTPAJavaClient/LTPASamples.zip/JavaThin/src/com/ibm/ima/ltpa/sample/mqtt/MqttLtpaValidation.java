/*
 * Copyright (c) 2012-2021 Contributors to the Eclipse Foundation
 * 
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 * 
 * SPDX-License-Identifier: EPL-2.0
 */
package com.ibm.ima.ltpa.sample.mqtt;

import java.io.FileInputStream;
import java.security.KeyStore;

import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;



public class MqttLtpaValidation implements  MqttCallback  {


	private String clientId = "testltpa";
	private String hostname = null;
	private String port = null;
	private String protocol = "ssl";
	private String username = null;
	private String password = null;
	private String keyStorePath = "c:/temp/ibm.jks";
	private String keyStorePasswordString = "password";
	private String sslProtocol = "TLSv1";

	private int exitCode = 0;



	public MqttLtpaValidation(String hostname, String port, String username, String password) {
		this.hostname = hostname;
		this.port = port;
		this.username = username;
		this.password = password;
	}

	private MqttClient getClient() throws MqttException {

		
		MqttClient client = new MqttClient(protocol + "://"+hostname+":"+port, clientId);
		client.setCallback(this);

		return client;

	}


	private void closeClient(MqttClient client) {

		try {
			client.disconnect();
		} catch (Throwable t) {

		}

		try {
			client.close();
		} catch (Throwable t) {
			// do not care about exception here...
		}


	}


	public void run()  {

		MqttClient client = null;
		

		
		try {


				client = getClient();
				MqttConnectOptions conOpt = new MqttConnectOptions();
				conOpt.setCleanSession(true);
				if (keyStorePath != null && protocol.equals("ssl")) {
					conOpt.setSocketFactory(getSocketFactory());
				}
				

				if (username != null) {
					conOpt.setUserName(username);
					conOpt.setPassword(password.toCharArray());
				}

				client.connect(conOpt);


			



		} catch (Throwable t) {

			t.printStackTrace();
		} finally {

			closeClient(client);

		}
	}

	private  SocketFactory getSocketFactory() throws Exception {


		try {

			KeyStore ks = KeyStore.getInstance("JKS");
			ks.load(new FileInputStream(keyStorePath), keyStorePasswordString.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance("IbmX509","IBMJSSE2");
			kmf.init(ks, keyStorePasswordString.toCharArray());

			TrustManager[] tm;
			TrustManagerFactory tmf = TrustManagerFactory.getInstance("PKIX","IBMJSSE2");
			tmf.init(ks);
			tm = tmf.getTrustManagers();

			SSLContext sslContext = SSLContext.getInstance(sslProtocol, "IBMJSSE2");
			sslContext.init(kmf.getKeyManagers(), tm, null);
			//SSLContext.setDefault(sslContext);
			return sslContext.getSocketFactory();

		} catch (Exception e) {
			System.out.println("Failed to read keystore file <" + keyStorePath + ">");
			throw e;
		}


	}


	public int getExitCode() {
		return exitCode;
	}

	@Override
	public void connectionLost(Throwable t) {



	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
		// TODO Auto-generated method stub


	}

	@Override
	public void messageArrived(String topic, MqttMessage msg) throws Exception {




	}



}
