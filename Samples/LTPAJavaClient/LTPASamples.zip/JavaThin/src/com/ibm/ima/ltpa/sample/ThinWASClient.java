package com.ibm.ima.ltpa.sample;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.apache.wink.client.ClientConfig;
import org.apache.wink.client.ClientResponse;
import org.apache.wink.client.Resource;
import org.apache.wink.client.RestClient;
import org.apache.wink.client.handlers.BasicAuthSecurityHandler;

public class ThinWASClient {
	
	static {
	    HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
			
			@Override
			public boolean verify(String hostname, SSLSession session) {
				// TODO Auto-generated method stub
				return true;
			}
		});
	        
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Configure client...
		ClientConfig clientConfig = new ClientConfig();
		
		// Use Basic Authentication
		BasicAuthSecurityHandler basicAuthSecHandler = new BasicAuthSecurityHandler(); 
		basicAuthSecHandler.setUserName("testuser"); basicAuthSecHandler.setPassword("testuser");
		clientConfig.handlers(basicAuthSecHandler);
		
		// Define resource
		RestClient client = new RestClient(clientConfig);
		Resource resource = client.resource("https://192.168.160.2:9087/ltpawebsample/rest/ltpa/token");
		ClientResponse response = resource.contentType("application/json").accept("*/*").get();
		
		System.out.println("The response code is: " + response.getStatusCode());
		System.out.println("The response message body is: " + response.getEntity(String.class));
		
		// Use the token as the password...
		String password = response.getEntity(String.class);
		
		// Send some messages!!
		//MqttLtpaValidation validator = new MqttLtpaValidation("192.168.160.2", "16102", "testuser","testuser" );
		//MqttLtpaValidation validator = new MqttLtpaValidation("192.168.160.2", "16102", "IMA_LTPA_AUTH",password );
		//MqttLtpaValidation validator = new MqttLtpaValidation("mar214.test.austin.ibm.com", "16102", "IMA_LTPA_AUTH",password );
		//validator.run();


	}

}
