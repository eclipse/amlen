package com.ibm.ima.resources;

import java.util.Set;

import javax.security.auth.Subject;
import javax.servlet.http.Cookie;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.ibm.websphere.security.auth.WSSubject;
import com.ibm.websphere.security.cred.WSCredential;
import com.ibm.websphere.security.web.WebSecurityHelper;
import com.ibm.ws.webservices.engine.encoding.Base64;


@Path("/ltpa")
@Produces(MediaType.APPLICATION_JSON)
public class LTPAResource {



	public LTPAResource() {

	}

	
	@GET
	@Path("token")
	@Produces({ MediaType.APPLICATION_JSON }) 
	public Response getLTPAToken() {


		String token = null;
		
		token = getSecurityToken();
		
		//token = getSecurityTokenLiberty();	
		
		CacheControl cache = new CacheControl();
		cache.setMaxAge(0);
		cache.setNoCache(true);
		cache.setNoStore(true);
		ResponseBuilder rb =  Response.ok(token);

		return rb.cacheControl(cache).build();


	}
	
	/**
	 * Works on Liberty - gives NoClassDefFound on WAS...
	 * 
	 * @return
	 */
	private  String getSecurityTokenLiberty(){
		
		Cookie cookie = null;
		String token = null;
		try {
			cookie = WebSecurityHelper.getSSOCookieFromSSOToken();
			if (cookie != null) {
				token = cookie.getValue();
			}
		} catch (Exception e) {
			token = "no token found";
			e.printStackTrace();
		}
		
		return token;
		
	}


	/**
	 * Works on WAS 8.5.5 Express...
	 * 
	 * @return an LTPA token
	 */
	private  String getSecurityToken(){

		byte[] token = null;
		
		try{
			
			// Get current security subject
			Subject security_subject = WSSubject.getRunAsSubject();
			
			if (security_subject != null){
				
				// Get all security credentials from the security subject
				Set security_credentials = security_subject.getPublicCredentials(WSCredential.class);

				// Get the first credential
				WSCredential security_credential = (WSCredential)security_credentials.iterator().next();
				String user = (String) security_credential.getSecurityName();
				if(user.equalsIgnoreCase("UNAUTHENTICATED")){
					return "UNAUTHENTICATED";
				}
				token = security_credential.getCredentialToken();
				if(token == null){
					return "token is null";
				}
				String ltpaToken = Base64.encode(token);
				return ltpaToken;
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}

		return "token not found";
	}

}
